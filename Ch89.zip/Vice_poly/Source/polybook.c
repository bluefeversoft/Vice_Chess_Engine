#include "defs.h"
#include "polykeys.h"

U64 PolyKeyFromBoard(S_BOARD *board) {
	return Random64Poly[400];
}