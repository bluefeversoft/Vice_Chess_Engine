// evaluate.c

#include "stdio.h"
#include "defs.h"

int EvalPosition(const S_BOARD *pos) {
	return 0;
}