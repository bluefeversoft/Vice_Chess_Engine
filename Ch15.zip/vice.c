// vice.c

#include "stdio.h"
#include "defs.h"
#include "stdlib.h"


int main() {

	AllInit();	
	
	return 0;
}