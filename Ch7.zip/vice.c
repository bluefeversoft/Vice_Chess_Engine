#include "stdio.h"
#include "defs.h"

int main() {

	AllInit();
		
	return 0;
}